#!/path/to/myenv/bin/python

from picamera import PiCamera
from time import sleep

camera = PiCamera()

camera.start_preview()
sleep(5)  # Allow time for the camera to warm up
camera.stop_preview()
